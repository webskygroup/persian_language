<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading
$_['heading_title']    = 'چک / حواله پول';

// Text
$_['text_instruction'] = 'دستورالعمل چک / حواله پول';
$_['text_payable']     = 'قابل پرداخت به: ';
$_['text_address']     = 'ارسال به: ';
$_['text_payment']     = 'سفارش شما تا رسیدن تاييدیه پرداخت قابل ارسال نمی باشد.';
?>