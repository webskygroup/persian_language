<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading
$_['heading_title']      = 'پرداخت آنلاین پارس پال';

// Text
$_['text_wait']  		 = 'لطفا صبر نمایید!';
$_['text_connect'] 		 = 'در حال اتصال به درگاه پارس پال ...';
$_['text_results']  	 = 'شماره رسید پرداخت پارس پال : ';

$_['button_view_cart']	 = 'مشاهده سبد خرید';
$_['button_complete']    = 'تکمیل پرداخت';
?>