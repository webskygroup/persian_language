<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading
$_['heading_title']        = 'پرداخت وجه هنگام تحویل';

// Error
$_['error_order_id']       = 'هیچ شناسه سفارشی در نشست موجود نیست!';
$_['error_payment_method'] = 'روش پرداخت نادرست می باشد!';
?>