<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading
$_['heading_title']   	   	= 'پرداخت آنلاین بانک ملت';

// Text
$_['text_wait']			   	= 'لطفا صبر کنید';
$_['text_heading']		   	= 'نتایج پرداخت';

$_['text_settled'] 	   	   	= 'واریز به حساب: ';
$_['text_orderId']	   	   	= 'شناسه سفارش: ';
$_['text_saleOrderId']	   	= 'شناسه خرید: ';
$_['text_saleReferenceId'] 	= 'شناسه ارجاع: ';

$_['text_settle_yes'] 		= 'انجام شد';
$_['text_settle_no']  		= 'ناموفق بود';

// Error
$_['error_order_id'] 		= 'خطا: سفارش مورد نظر یافت نشد!';
?>