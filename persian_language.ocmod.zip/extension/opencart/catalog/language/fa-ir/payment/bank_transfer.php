<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading
$_['heading_title']    = 'پرداخت نقدی';

// Text
$_['text_instruction'] = 'راهنمای پرداخت نقدی';
$_['text_description'] = 'لطفا مبلغ کل را به حساب بانکی زير واریز نمایيد.';
$_['text_payment']     = 'سفارش شما تا رسیدن تاييدیه پرداخت قابل ارسال نمی باشد.';
?>