<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Text
$_['text_captcha']  = 'کد امنیتی';

// Entry
$_['entry_captcha'] = 'کد امنیتی را در کادر زیر وارد نمایید';

// Error
$_['error_captcha'] = 'کد وارد شده با تصویر هماهنگ نیست!';
?>