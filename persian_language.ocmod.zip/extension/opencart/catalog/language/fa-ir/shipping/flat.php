<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading
$_['heading_title']    = 'پست پيشتاز';

// Text
$_['text_description'] = 'هزینه پست پيشتاز';   
?>