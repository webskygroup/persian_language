<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Text
$_['text_credit']   = 'اعتبار فروشگاه';
$_['text_order_id'] = 'شناسه سفارش: #%s';
?>