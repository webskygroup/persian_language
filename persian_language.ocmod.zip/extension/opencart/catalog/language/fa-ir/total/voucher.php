<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading
$_['heading_title'] = 'استفاده از کارت هدیه';

// Text
$_['text_voucher']  = 'کارت هدیه (%s)';
$_['text_success']  = 'تخفیف کارت هدیه با موفقیت اعمال شد!';
$_['text_remove']   = 'تخفیف کارت هدیه با موفقیت حذف شد!';

// Entry
$_['entry_voucher'] = 'کد کارت هدیه را در اینجا وارد کنید';

// Error
$_['error_voucher'] = 'هشدار: کارت هدیه نامعتبر است یا اعتبار آن استفاده شده است!';
$_['error_status']  = 'هشدار: امکان استفاده از کارت هدیه در این فروشگاه فعال نیست!';
?>