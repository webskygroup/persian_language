<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading
$_['heading_title'] = 'استفاده از کد کوپن';

// Text
$_['text_coupon']   = 'کوپن (%s)';
$_['text_success']  = 'کوپن تخفیف با موفقیت اعمال شد!';
$_['text_remove']   = 'کوپن تخفیف با موفقیت حذف شد!';

// Entry
$_['entry_coupon']  = 'کد کوپن را در اینجا وارد کنید';

// Error
$_['error_coupon']  = 'هشدار: کوپن ناممعتبر است، منقضی شده یا تعداد آن استفاده شده است!';
$_['error_status']  = 'هشدار: امکان استفاده از کوپن در این فروشگاه فعال نیست!';
?>