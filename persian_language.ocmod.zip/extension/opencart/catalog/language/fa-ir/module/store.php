<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading 
$_['heading_title'] = 'یک فروشگاه انتخاب نمایید';

// Text
$_['text_default']  = 'پیش فرض';
$_['text_store']    = 'لطفا فروشگاهی که قصد بازدید از آن را دارید انتخاب نمایید.';
?>