<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading
$_['heading_title']     = 'محتوای HTML';

// Text
$_['text_extension']    = 'افزونه ها';
$_['text_success']      = 'ماژول محتوای HTML با موفقیت ویرایش شد!';
$_['text_edit']         = 'ویرایش ماژول محتوای HTML';

// Entry
$_['entry_name']        = 'نام ماژول';
$_['entry_title']       = 'عنوان';
$_['entry_description'] = 'محتوا';
$_['entry_status']      = 'وضعیت';

// Error
$_['error_permission']  = 'هشدار: شما اجازه ویرایش ماژول محتوای HTML را ندارید!';
$_['error_name']        = 'نام ماژول باید بین 3 تا 64 کاراکتر باشد!';
?>