<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading
$_['heading_title']    = 'دسته بندی'; 

// Text
$_['text_extension']   = 'افزونه ها';
$_['text_success']     = 'ماژول دسته بندی با موفقیت ویرایش شد!';
$_['text_edit']        = 'ویرایش ماژول دسته بندی';

// Entry
$_['entry_status']     = 'وضعیت';

// Error
$_['error_permission'] = 'هشدار: شما اجازه ویرایش ماژول دسته بندی را ندارید!';
?>