<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading
$_['heading_title']    = 'فروشگاه';

// Text
$_['text_extension']   = 'افزونه ها';
$_['text_success']     = 'ماژول فروشگاه با موفقیت ویرایش شد!';
$_['text_edit']        = 'ویرایش ماژول فروشگاه';

// Entry
$_['entry_admin']      = 'فقط کاربران مدیریت';
$_['entry_status']     = 'وضعیت';

// Error
$_['error_permission'] = 'هشدار: شما اجازه ویرایش ماژول فروشگاه را ندارید!';
?>