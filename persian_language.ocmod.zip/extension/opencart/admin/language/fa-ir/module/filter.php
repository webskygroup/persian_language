<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading
$_['heading_title']    = 'فیلتر'; 

// Text
$_['text_extension']   = 'افزونه ها';
$_['text_success']     = 'ماژول فیلتر با موفقیت ویرایش شد!';
$_['text_edit']        = 'ویرایش ماژول فیلتر';

// Entry
$_['entry_status']     = 'وضعیت';

// Error
$_['error_permission'] = 'هشدار: شما اجازه ویرایش ماژول فیلتر را ندارید!';
?>