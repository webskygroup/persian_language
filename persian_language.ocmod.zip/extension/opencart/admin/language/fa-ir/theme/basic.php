<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading
$_['heading_title']    = 'قالب پیش فرض فروشگاه';

// Text
$_['text_extension']   = 'افزونه ها';
$_['text_success']     = 'قالب پیش فرض فروشگاه با موفقیت ویرایش شد!';
$_['text_edit']        = 'ویرایش قالب پیش فرض فروشگاه';

// Entry
$_['entry_status']	   = 'وضعیت';

// Error
$_['error_permission'] = 'هشدار: شما اجازه ویرایش قالب پیش فرض فروشگاه را ندارید!';
?>