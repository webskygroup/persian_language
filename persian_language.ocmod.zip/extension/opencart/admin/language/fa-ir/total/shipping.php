<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading
$_['heading_title']    = 'حمل و نقل';

// Text
$_['text_extension']   = 'افزونه ها';
$_['text_success']     = 'حمل و نقل با موفقیت ویرایش شد!';
$_['text_edit']        = 'ویرایش جمع کل حمل و نقل';

// Entry
$_['entry_estimator']  = 'تخمین حمل و نقل';
$_['entry_status']     = 'وضعیت';
$_['entry_sort_order'] = 'ترتیب';

// Error
$_['error_permission'] = 'هشدار: شما اجازه ویرایش حمل و نقل را ندارید!';
?>