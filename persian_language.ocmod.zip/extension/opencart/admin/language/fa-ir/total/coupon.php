<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading
$_['heading_title']    = 'کوپن';

// Text
$_['text_extension']   = 'افزونه ها';
$_['text_success']     = 'کوپن با موفقیت ویرایش شد!';
$_['text_edit']        = 'ویرایش کوپن';

// Entry
$_['entry_status']     = 'وضعیت';
$_['entry_sort_order'] = 'ترتیب';

// Error
$_['error_permission'] = 'هشدار: شما اجازه ویرایش کوپن را ندارید!';
?>