<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading
$_['heading_title']    = 'امتیاز جایزه';

// Text
$_['text_extension']   = 'افزونه ها';
$_['text_success']     = 'امتیاز جایزه با موفقیت ویرایش شد!';
$_['text_edit']        = 'ویرایش جمع کل امتیاز جایزه';

// Entry
$_['entry_status']     = 'وضعیت';
$_['entry_sort_order'] = 'ترتیب';

// Error
$_['error_permission'] = 'هشدار: شما اجازه ویرایش امتیاز جایزه را ندارید!';
?>