<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading
$_['heading_title']    = 'جمع کل';

// Text
$_['text_extension']   = 'افزونه ها';
$_['text_success']     = 'ماژول جمع کل با موفقیت ویرایش شد!';
$_['text_edit']        = 'ویرایش ماژول جمع کل';

// Entry
$_['entry_status']     = 'وضعیت';
$_['entry_sort_order'] = 'ترتیب';

// Error
$_['error_permission'] = 'هشدار: شما اجازه ویرایش ماژول جمع کل را ندارید!';
?>