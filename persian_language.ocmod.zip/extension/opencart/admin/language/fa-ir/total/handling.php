<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading
$_['heading_title']    = 'هزينه کارمزد';

// Text
$_['text_extension']   = 'افزونه ها';
$_['text_success']     = 'هزینه کارمزد با موفقیت تویرایش شد!';
$_['text_edit']        = 'ویرایش جمع کل هزينه کارمزد';

// Entry
$_['entry_total']      = 'جمع کل سفارش';
$_['entry_fee']        = 'هزینه';
$_['entry_tax_class']  = 'کلاس مالیاتی';
$_['entry_status']     = 'وضعیت';
$_['entry_sort_order'] = 'ترتیب';

// Help
$_['help_total']       = 'جمع کل سفارش قبل از اینکه این روش فعال شود.';

// Error
$_['error_permission'] = 'هشدار: شما اجازه ویرایش هزینه کارمزد را ندارید!';
?>