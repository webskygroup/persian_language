<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading
$_['heading_title']    = 'ارسال براساس وزن';

// Text
$_['text_extension']   = 'افزونه ها';
$_['text_success']     = 'ارسال براساس وزن با موفقیت ویرایش شد!';
$_['text_edit']        = 'ویرایش ارسال براساس وزن';

// Entry
$_['entry_rate']       = 'نرخ ها';
$_['entry_tax_class']  = 'کلاس مالیاتی';
$_['entry_geo_zone']   = 'منطقه جغرافیایی';
$_['entry_status']     = 'وضعیت';
$_['entry_sort_order'] = 'ترتیب';

// Help
$_['help_rate']        = 'به عنوان مثال : 5:10.00,7:12.00 وزن: هزینه,وزن: هزینه، و غیره.';

// Error
$_['error_permission'] = 'هشدار: شما اجازه ویرایش ارسال براساس وزن را ندارید!';
?>