<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading
$_['heading_title']    = 'پست پيشتاز';

// Text
$_['text_extension']   = 'افزونه ها';
$_['text_success']     = 'پست پیشتاز با موفقیت ویرایش شد!';
$_['text_edit']        = 'ویرایش پست پيشتاز';

// Entry
$_['entry_cost']       = 'هزینه';
$_['entry_tax_class']  = 'کلاس مالیاتی';
$_['entry_geo_zone']   = 'منطقه جغرافیایی';
$_['entry_status']     = 'وضعیت';
$_['entry_sort_order'] = 'ترتیب';

// Error
$_['error_permission'] = 'هشدار: شما اجازه ویرایش پست پیشتاز را ندارید!';
?>