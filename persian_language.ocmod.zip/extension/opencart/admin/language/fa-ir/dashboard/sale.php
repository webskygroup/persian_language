<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading
$_['heading_title']    = 'جمع کل فروش';

// Text
$_['text_extension']   = 'افزونه ها';
$_['text_success']     = 'فروش های پیشخوان با موفقیت ویرایش شد!';
$_['text_edit']        = 'ویرایش فروش های پیشخوان';
$_['text_view']        = 'مشاهده بیشتر...';

// Entry
$_['entry_status']     = 'وضعیت';
$_['entry_sort_order'] = 'ترتیب';
$_['entry_width']      = 'عرض';

// Error
$_['error_permission'] = 'هشدار: شما اجازه ویرایش فروش های پیشخوان را ندارید!';
?>