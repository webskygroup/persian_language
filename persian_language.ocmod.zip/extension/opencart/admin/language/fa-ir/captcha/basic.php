<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading
$_['heading_title']    = 'کد امنیتی پایه';

// Text
$_['text_extension']   = 'افزونه ها';
$_['text_success']	   = 'کد امنیتی پایه با موفقیت ویرایش شد!';
$_['text_edit']        = 'ویرایش کد امنیتی گوگل';

// Entry
$_['entry_status']     = 'وضعیت';

// Error
$_['error_permission'] = 'هشدار: شما اجازه ویرایش کد امنیتی پایه را ندارید!';
?>