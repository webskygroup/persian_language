<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading
$_['heading_title']      = 'پرداخت رايگان';

// Text
$_['text_extension']	 = 'افزونه ها';
$_['text_success']       = 'پرداخت رایگان با موفقیت ویرایش شد!';
$_['text_edit']          = 'ویرایش پرداخت رايگان';

// Entry
$_['entry_order_status'] = 'وضعیت سفارش';
$_['entry_status']       = 'وضعیت';
$_['entry_sort_order']   = 'ترتیب';

// Error
$_['error_permission']   = 'هشدار: شما اجازه ویرایش پرداخت رایگان را ندارید!';
?>