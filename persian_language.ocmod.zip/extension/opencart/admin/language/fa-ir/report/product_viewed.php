<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading
$_['heading_title']    = 'گزارش محصولات مشاهده شده';

// Text
$_['text_extension']   = 'افزونه ها';
$_['text_edit']        = 'ویرایش گزارش محصولات مشاهده شده';
$_['text_success']     = 'گزارش محصولات مشاهده شده با موفقیت بازنشانی گردید!';
$_['text_progress']    = 'پیشرفت %s از %s!';

// Column
$_['column_name']      = 'نام محصول';
$_['column_model']     = 'مدل';
$_['column_viewed']    = 'تعداد بازديد';
$_['column_percent']   = 'درصد';

// Entry
$_['entry_status']     = 'وضعیت';
$_['entry_sort_order'] = 'ترتیب';

// Error
$_['error_permission'] = 'هشدار: شما اجازه ویرایش گزارش محصولات مشاهده شده را ندارید!';
?>