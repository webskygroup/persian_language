<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading
$_['heading_title']    = 'مبدل واحد پول بانک مرکزی اروپا';

// Text
$_['text_extension']   = 'افزونه ها';
$_['text_success']     = 'مبدل واحد پول بانک مرکزی اروپا با موفقیت ویرایش شد!';
$_['text_edit']        = 'ویرایش مبدل واحد پول بانک مرکزی اروپا';
$_['text_support']     = 'این افزونه به واحد پول یورویی نیاز دارد تا در بخش واحد پول در دسترس باشد.';

// Entry
$_['entry_status']     = 'وضعیت';

// Error
$_['error_permission'] = 'هشدار: شما اجازه ویرایش مبدل واحد پول بانک مرکزی اروپا را ندارید!';
?>