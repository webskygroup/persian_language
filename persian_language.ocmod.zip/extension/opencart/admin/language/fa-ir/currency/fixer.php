<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading
$_['heading_title']    = 'اصلاح کننده';

// Text
$_['text_extension']   = 'افزونه ها';
$_['text_success']     = 'اصلاح کننده واحد پول با موفقیت ویرایش شد!';
$_['text_edit']        = 'ویرایش اصلاح کننده';
$_['text_signup']      = 'Fixer.io یک سرویس تبدیل واحد پول است <a href="https://fixer.io/" target="_blank" class="alert-link">برای ثبت نام اینجا کلیک کنید</a>.';
$_['text_support']     = 'این افزونه به واحد پول یورویی نیاز دارد تا در بخش واحد پول در دسترس باشد.';

// Entry
$_['entry_api']        = 'کلید دسترسی API';
$_['entry_status']     = 'وضعیت';

// Error
$_['error_permission'] = 'هشدار: شما اجازه ویرایش نرخ واحد پول اصلاح کننده را ندارید!';
$_['error_api']        = 'کلید دسترسی API موردنیاز می باشد!';
?>