<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Text
$_['text_cart']       = 'سبد خرید با موفقیت بروزرسانی شد!';
$_['text_for']        = '%s کارت هدیه برای %s';
$_['text_success']    = 'تخفیف کارت هدیه با موفقیت اعمال شد!';
$_['text_remove']     = 'تخفیف کارت هدیه با موفقیت حذف شد!';

// Error
$_['error_voucher']   = 'هشدار: کارت هدیه نامعتبر است یا اعتبار آن استفاده شده است!';
$_['error_to_name']   = 'نام گیرنده باید بین 1 تا 64 کاراکتر باشد!';
$_['error_from_name'] = 'نام شما باید بین 1 تا 64 کاراکتر باشد!';
$_['error_email']     = 'آدرس ایمیل نامعتبر می باشد!';
$_['error_theme']     = 'شما باید یک قالب انتخاب کنید!';
$_['error_amount']    = 'مقدار باید بین %s و %s باشد!';
?>