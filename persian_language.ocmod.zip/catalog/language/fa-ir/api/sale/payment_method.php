<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Text
$_['text_success']          = 'روش پرداخت شما با موفقیت اعمال شد!';

// Error
$_['error_payment_address'] = 'هشدار: آدرس پرداخت موردنیاز می باشد!';
$_['error_payment_method']  = 'هشدار: روش پرداخت موردنیاز می باشد!';
$_['error_no_payment']      = 'هشدار: هیچ گزینه پرداختی موجود نمی باشد!';
$_['error_product']         = 'هشدار: محصولات موردنیاز می باشد!';
?>