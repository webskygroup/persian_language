<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Text
$_['text_success']           = 'روش حمل و نقل با موفقیت اعمال شد!';

// Error
$_['error_shipping_address'] = 'هشدار: آدرس حمل و نقل موردنیاز می باشد!';
$_['error_shipping_method']  = 'هشدار: روش حمل و نقل موردنیاز می باشد!';
$_['error_no_shipping']      = 'هشدار: هیچ گزینه حمل و نقلی موجود نمی باشد!';
$_['error_shipping']         = 'هشدار: هیچ محصولی که نیاز به ححمل و نقل داشته باشد وجود ندارد';
?>