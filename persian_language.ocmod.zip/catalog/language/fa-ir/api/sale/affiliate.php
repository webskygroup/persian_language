<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Text
$_['text_success']    = 'تبریک: کمیسیون بازاریابی به این سفارش اعمال خواهد شد!';
$_['text_remove']     = 'تبریک: کمیسیون بازاریابی شما حذف شد!';

// Error
$_['error_affiliate'] = 'هشدار: بازاریاب را نمی توان پیدا کرد!';
?>