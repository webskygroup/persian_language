<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Text
$_['text_success']  = 'تخفیف امتیاز جایزه با موفقیت اعمال شد!';
$_['text_remove']   = 'تخفیف امتیاز جایزه با موفقیت حذف شد!';

// Error
$_['error_reward']  = 'هشدار: لطفا مقدار امتیاز جایزه را برای استفاده وارد کنید!';
$_['error_points']  = 'هشدار: شما %s امتیاز جایزه ندارید!';
$_['error_maximum'] = 'هشدار: حداکثر امتیاز جایزه قابل اعمال %s می باشد!';
?>