<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Text
$_['text_success'] = 'کوپن تخفیف شما با موفقیت اعمال شد!';
$_['text_success'] = 'کوپن تخفیف شما با موفقیت حذف شد!';

// Error
$_['error_coupon'] = 'هشدار: کوپن نامعتبر است، منقضی شده یا تعداد آن استفاده شده است!';
?>