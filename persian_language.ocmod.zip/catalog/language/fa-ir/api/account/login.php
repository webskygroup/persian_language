<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Text
$_['text_success']     = 'نشست API با موفقیت شروع شد!';

// Error
$_['error_permission'] = 'هشدار: شما اجازه دسترسی به API را ندارید!';
$_['error_key']    	   = 'هشدار: کلید API نادرست می باشد!';
$_['error_ip']         = 'هشدار: آی پی شما %s اجازه دسترسی به این API را ندارد!';
?>