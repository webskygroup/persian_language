<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Text
$_['text_success']     = 'واحد پول با موفقیت تغییر یافت!';

// Error
$_['error_currency']   = 'هشدار: واحد پول را نمی توان پیدا کرد!';
?>