<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Text
$_['text_success']   = 'زبان شما با موفقیت تغییر یافت!';

// Error
$_['error_language'] = 'هشدار: زبان را نمی توان پیدا کرد!';
?>