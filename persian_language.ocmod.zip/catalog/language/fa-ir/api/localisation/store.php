<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Text
$_['text_success'] = 'فروشگاه با موفقیت تغییر یافت!';

// Error
$_['error_store']  = 'هشدار: فروشگاه را نمی توان پیدا کرد!';
?>