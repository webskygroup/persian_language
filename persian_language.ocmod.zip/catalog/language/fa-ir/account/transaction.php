<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading 
$_['heading_title']      = 'تراکنش های شما';

// Column
$_['column_date_added']  = 'تاریخ افزودن';
$_['column_description'] = 'توضیحات';
$_['column_amount']      = 'مقدار (%s)';

// Text
$_['text_account']       = 'حساب کاربری';
$_['text_transaction']   = 'تراکنش های شما';
$_['text_total']         = 'موجودی شما:';
$_['text_no_results']    = 'شما هیچ تراکنشی نداشته اید!';
?>