<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading 
$_['heading_title']     = 'دانلودهای حساب کاربری';

// Text
$_['text_account']      = 'حساب کاربری';
$_['text_downloads']  	= 'دانلودها';
$_['text_no_results']   = 'شما هیچ سفارش قابل دانلودی ندارید!';

// Column
$_['column_order_id']   = 'شناسه سفارش';
$_['column_name']       = 'نام';
$_['column_size']       = 'اندازه';
$_['column_date_added'] = 'تاریخ افزودن';

// Error
$_['error_not_found']    = 'خطا: فایل %s را نمی توان پیدا کرد!';
$_['error_headers_sent'] = 'خطا: هدر قبلاً ارسال شده است!';
?>