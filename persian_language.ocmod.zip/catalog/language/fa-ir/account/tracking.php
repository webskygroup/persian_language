<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading 
$_['heading_title']    = 'پیگیری بازاریابی';

// Text
$_['text_account']     = 'حساب کاربری';
$_['text_description'] = '‫برای اطمینان از پرداخت افرادی که شما برای ما فرستاده اید، نیاز است تا شما یک کد پیگیری در آدرسی که به ما متصل است، ایجاد نمایید. شما می توانید از ابزار زیر جهت تولید لینک به وب سایت %s استفاده نمایید.';

// Entry
$_['entry_code']       = 'کد پیگیری شما';
$_['entry_generator']  = 'ایجاد لینک پیگیری';
$_['entry_link']       = 'لینک پیگیری';

// Help
$_['help_generator']   = 'نام محصولی که قصد ایجاد پیوند به آن را دارید تایپ نمایید';
?>