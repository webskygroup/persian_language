<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading 
$_['heading_title']    = 'اشتراک خبرنامه';

// Text
$_['text_account']     = 'حساب کاربری';
$_['text_newsletter']  = 'خبرنامه';
$_['text_success']     = 'اشتراک خبرنامه شما با موفقیت بروزرسانی شد!';

// Entry
$_['entry_newsletter'] = 'اشتراک';
?>
