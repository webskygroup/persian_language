<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading 
$_['heading_title']  = 'تغییر رمز عبور';

// Text
$_['text_account']   = 'حساب کاربری';
$_['text_password']  = 'رمز عبور';
$_['text_success']   = 'رمز عبور شما با موفقيت بروزرسانی شد!';

// Entry
$_['entry_password'] = 'رمز عبور';
$_['entry_confirm']  = 'تکرار رمز عبور';

// Error
$_['error_token']    = 'هشدار: توکن رمز عبور نامعتبر است!';
$_['error_password'] = 'رمز عبور باید بین 4 تا 20 کاراکتر باشد!';
$_['error_confirm']  = 'تکرار رمز عبور با رمز عبور مطابقت ندارد!';
?>