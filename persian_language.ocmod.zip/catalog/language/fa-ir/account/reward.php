<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading 
$_['heading_title']      = 'امتیاز های جایزه شما';

// Column
$_['column_date_added']  = 'تاریخ افزودن';
$_['column_description'] = 'توضیحات';
$_['column_points']      = 'امتیازها';

// Text
$_['text_account']       = 'حساب کاربری';
$_['text_reward']        = 'امتیاز های جایزه';
$_['text_total']         = 'جمع کل امتیاز های جایزه شما:';
$_['text_no_results']    = 'شما هیچ امتیاز جایزه ای ندارید!';
?>