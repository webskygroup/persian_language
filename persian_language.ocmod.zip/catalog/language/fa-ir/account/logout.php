<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading 
$_['heading_title'] = 'خروج از حساب کاربری';

// Text
$_['text_message']  = '<p>شما از حساب خود خارج شده اید.</p><p> سبد خرید شما ذخیره شده است، هر زمان دوباره وارد حسابتان شدید می توانید خرید خود را ادامه دهید.</p>';
$_['text_account']  = 'حساب کاربری';
$_['text_logout']   = 'خروج';
?>