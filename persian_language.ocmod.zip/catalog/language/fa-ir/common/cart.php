<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Text
$_['text_items']     			 = '%s محصول - %s';
$_['text_subscription']          = 'اشتراک';
$_['text_subscription_trial']    = '%s هر %d %s برای %d پرداخت از ';
$_['text_subscription_duration'] = '%s هر %d %s برای %d پرداخت';
$_['text_subscription_cancel']   = '%s هر %d %s تا کنسل شود';
$_['text_day']                   = 'روز';
$_['text_week']                  = 'هفته';
$_['text_semi_month']            = 'پانزده روز';
$_['text_month']                 = 'ماه';
$_['text_year']                  = 'سال';
$_['text_no_results']            = 'سبد خرید شما خالی است!';
$_['text_cart']      			 = 'مشاهده سبدخرید';
$_['text_checkout']  			 = 'تسویه حساب';
?>