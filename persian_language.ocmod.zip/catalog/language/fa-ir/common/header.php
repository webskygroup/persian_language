<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Text
$_['text_wishlist']      = 'لیست دلخواه (%s)';
$_['text_shopping_cart'] = 'سبد خرید';
$_['text_account']       = 'حساب کاربری';
$_['text_register']      = 'عضویت';
$_['text_login']         = 'ورود';
$_['text_order']         = 'تاریخچه سفارش ها';
$_['text_transaction']   = 'تراکنش ها';
$_['text_download']      = 'دانلودها';
$_['text_logout']        = 'خروج';
$_['text_checkout']      = 'تسویه حساب';
?>