<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Text
$_['text_success'] = 'از اینکه به ما از انتخابتان اطلاع دادید متشکریم!';
$_['text_cookie']  = 'این وب سایت از کوکی استفاده می کند. برای اطلاعات بیشتر <a href="%s" class="alert-link modal-link">اینجا کلیک کنید</a>.';

// Button
$_['button_agree']    = 'بله، خوب است!';
$_['button_disagree'] = 'نه متشکرم!';
?>