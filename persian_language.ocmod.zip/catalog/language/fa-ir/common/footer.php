<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Text
$_['text_information']  = 'اطلاعات';
$_['text_service']      = 'خدمات مشتریان';
$_['text_extra']        = 'سایر خدمات';
$_['text_contact']      = 'تماس با ما';
$_['text_return']       = 'استرداد محصول';
$_['text_sitemap']      = 'نقشه سایت';
$_['text_gdpr']         = 'GDPR';
$_['text_manufacturer'] = 'تولید کنندگان';
$_['text_voucher']      = 'کارت هدیه';
$_['text_affiliate']    = 'بازاریابی';
$_['text_special']      = 'محصولات ویژه';
$_['text_account']      = 'حساب کاربری';
$_['text_order']        = 'تاریخچه سفارش ها';
$_['text_wishlist']     = 'لیست دلخواه';
$_['text_newsletter']   = 'اشتراک خبرنامه';
$_['text_powered']      = '<a href="https://opencartfarsi.com" title="انجمن پشتیبانی OpenCartFarsi.Com" target="_blank">پشتیبانی و توسعه</a> توسط <a href="https://www.opencart-ir.com" title="وب سایت OpenCartFarsi.ir" target="_blank">اپن کارت فارسی</a> <br /> %s &copy; %s';

?>