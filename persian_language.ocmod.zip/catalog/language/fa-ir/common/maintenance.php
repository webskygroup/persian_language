<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading
$_['heading_title']    = 'در دست تعمیر است';

// Text
$_['text_maintenance'] = 'تعمیرات';
$_['text_message']     = '<h1 style="text-align:center;">در حال حاضر در حال تعمیرات هستیم. <br/>در اولین فرصت ممکن بر می گردیم. لطفا بعدا مراجعه نمایید.</h1>';
?>