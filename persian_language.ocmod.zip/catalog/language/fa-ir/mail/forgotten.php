<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Text
$_['text_subject']  = '%s - درخواست بازنشانی رمز عبور';
$_['text_greeting'] = 'یک رمز عبور جدید برای حساب مشتری %s درخواست شده است.';
$_['text_change']   = 'برای بازنشانی رمز عبور روی لینک زیر کلیک نمایید:';
$_['text_ip']       = 'این درخواست از طریق این آی پی درخواست شده است:';

// Button
$_['button_reset']  = 'بازنشانی رمز عبور';
?>