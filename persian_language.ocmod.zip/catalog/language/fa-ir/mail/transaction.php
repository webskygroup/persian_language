<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Text
$_['text_subject']  = '%s - کمیسیون بازاریابی';
$_['text_received'] = 'تبریک! شما یک پرداخت کمیسیون از طریق %s برنامه بازاریابی داشته اید';
$_['text_amount']   = 'دریافتی شما:';
$_['text_total']    = 'کل مقدار کمیسیون شما برابر است با:';
?>