<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Text
$_['text_subject']      = '%s - بروزرسانی سفارش %s';
$_['text_order_id']     = 'شناسه سفارش:';
$_['text_date_added']   = 'تاریخ سفارش:';
$_['text_order_status'] = 'سفارش شما به وضعیت زیر بروز رسانی شده است:';
$_['text_comment']      = 'توضیحات سفارش شما:';
$_['text_link']         = 'برای مشاهده سفارش خود روی لينک زير کليک نمایيد:';
$_['text_footer']       = 'لطفا اگر هرگونه سوالی دارید همین ایمیل را پاسخ دهید.';
?>