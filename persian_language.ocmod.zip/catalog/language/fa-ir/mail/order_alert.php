<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Text
$_['text_subject']      = '%s - سفارش %s';
$_['text_received']     = 'شما يک سفارش دريافت کرده ايد.';
$_['text_order_id']     = 'شناسه سفارش:';
$_['text_date_added']   = 'تاریخ افزوده شدن:';
$_['text_order_status'] = 'وضعیت سفارش:';
$_['text_product']      = 'محصولات:';
$_['text_total']        = 'جمع کل:';
$_['text_comment']      = 'توضیحات سفارش شما:';
?>