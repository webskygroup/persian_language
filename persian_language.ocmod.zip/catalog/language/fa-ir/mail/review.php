<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Text
$_['text_subject']	= '%s - نظر محصول';
$_['text_waiting']	= 'شما یک نظر جدید در انتظار تایید برای محصولتان دریافت کرده اید.';
$_['text_product']	= 'محصول:';
$_['text_reviewer']	= 'نظر دهنده:';
$_['text_rating']	= 'رتبه:';
$_['text_review']	= 'متن نظر:';