<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading
$_['heading_title'] = 'GDPR موفق';

// Text
$_['text_account']  = 'حساب کاربری';
$_['text_export']   = 'یک درخواست برای تهیه بکاپ اطلاعات حساب کاربری شما دریافت شده است.';
$_['text_remove']   = 'درخواست حذف حساب کاربری پس از <strong>%s روز</strong> پردازش می شود، بنابراین می توان هرگونه بازپرداخت، بازگشت وجه یا تشخیص کلاهبرداری را پردازش کرد.';
?>