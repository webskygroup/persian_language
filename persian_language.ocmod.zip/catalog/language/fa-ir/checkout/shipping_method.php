<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading
$_['heading_title']          = 'روش حمل و نقل';

// Text
$_['text_shipping_method']   = 'گزینه های روش حمل و نقل';
$_['text_shipping']          = 'لطفاً روش ارسال ترجیحی را برای استفاده برای این سفارش انتخاب کنید.';

// Entry
$_['entry_shipping_method']  = 'انتخاب روش حمل و نقل';
// Text
$_['text_success']           = 'روش حمل و نقل با موفقیت تغییر یافت!';

// Error
$_['error_shipping_address'] = 'هشدار: آدرس حمل و نقل موردنیاز می باشد!';
$_['error_shipping_method']  = 'هشدار: روش حمل و نقل موردنیاز می باشد!';
$_['error_no_shipping']      = 'هشدار: هیچ گزینه حمل و نقلی وجود ندارد. لطفا برای رسیدگی به این مشکل با ما <a href="%s">تماس بگیرید</a>!';
?>