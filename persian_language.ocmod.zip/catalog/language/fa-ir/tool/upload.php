<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Text
$_['text_upload']     = 'فایل شما با موفقیت آپلود شد!';

// Error
$_['error_filename']  = 'نام فایل باید بین 3 تا 64 کاراکتر باشد!';
$_['error_file_type'] = 'نوع فایل نامعتبر می باشد!';
$_['error_upload']    = 'آپلود موردنیاز می باشد!';
