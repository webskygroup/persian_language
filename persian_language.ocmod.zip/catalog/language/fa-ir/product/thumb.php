<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Text
$_['text_price'] = 'قیمت:';
$_['text_tax']   = 'قیمت بدون مالیات:';
?>