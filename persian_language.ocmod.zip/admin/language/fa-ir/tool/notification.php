<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading
$_['heading_title']    = 'اطلاع رسانی ها';

// Text
$_['text_success']     = 'اطلاع رسانی با موفقیت ویرایش شد!';
$_['text_list']        = 'لیست اطلاع رسانی ها';

// Column
$_['column_message']   = 'پیام';
$_['column_action']    = 'عملیات';

// Error
$_['error_permission'] = 'هشدار: شما اجازه ویرایش اطلاع رسانی ها را ندارید!';
?>