<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading
$_['heading_title']    = 'ليست خطاها';

// Text
$_['text_success']     = 'لیست خطاها با موفقیت پاک شد!';
$_['text_list']        = 'لیست خطاها';

// Error
$_['error_permission'] = 'هشدار: شما اجازه پاک کردن ليست خطاها را ندارید!';
$_['error_file']       = 'هشدار: %s فایل را نمی توان پیدا کرد!';
$_['error_size']       = 'هشدار: فایل گزارش خطا %s اندازه اش %s می باشد!';
$_['error_empty']      = 'هشدار: فایل گزاش خطا %s خالی می باشد!';
?>