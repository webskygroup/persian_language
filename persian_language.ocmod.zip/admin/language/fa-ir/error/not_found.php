<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading
$_['heading_title']  = 'صفحه مورد نظر پیدا نشد!';

// Text
$_['text_not_found'] = 'صفحه درخواستی شما پیدا نشد! اگر همچنان مشکل وجود دارد با مدیریت تماس بگیرید.';
?>
