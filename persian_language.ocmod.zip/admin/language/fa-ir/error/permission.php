<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading
$_['heading_title']   = 'دسترسی غیرمجاز است!'; 

// Text
$_['text_permission'] = 'شما اجازه دسترسی به این صفحه را ندارید، لطفا با مدیریت سیستم تماس بگیرید.';
?>