<?php
// Heading
$_['heading_title']      = 'مرکزخرید افزونه';

// Text
$_['text_success']       = 'افزونه با موفقیت ویرایش شد!';
$_['text_list']          = 'لیست افزونه ها';

// Column
$_['column_name']      = 'نام مرکز خرید';
$_['column_status']    = 'وضعیت';
$_['column_action']    = 'عملیات';

// Error
$_['error_permission']   = 'هشدار: شما اجازه دسترسی یا ویرایش افزونه ها را ندارید!';

$_['error_extension']  = 'هشدار: ماژول وجود ندارد!';