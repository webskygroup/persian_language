<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading
$_['heading_title']    = 'شناسایی متقلبین';

// Text
$_['text_success']     = 'شناسایی متقلبین با موفقیت ویرایش شد!';
$_['text_list']        = 'لیست شناسایی متقلبین';

// Column
$_['column_name']      = 'نام شناسایی متقلب';
$_['column_status']    = 'وضعیت';
$_['column_action']    = 'عملیات';

// Error
$_['error_permission'] = 'هشدار: شما اجازه ویرایش شناسایی متقلبین را ندارید!';
$_['error_extension']  = 'هشدار: افزونه موجود نیست!';
?>