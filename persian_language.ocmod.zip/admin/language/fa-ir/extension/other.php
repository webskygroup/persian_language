<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading
$_['heading_title']    = 'سایر';

// Text
$_['text_success']     = 'سایر افزونه با موفقیت ویرایش شد!';
$_['text_list']        = 'لیست سایر';

// Column
$_['column_name']      = 'سایر';
$_['column_status']    = 'وضعیت';
$_['column_action']    = 'عملیات';

// Error
$_['error_permission'] = 'هشدار: شما اجازه ویرایش سایر افزونه را ندارید!';
$_['error_extension']  = 'هشدار: افزونه موجود نیست!';
?>