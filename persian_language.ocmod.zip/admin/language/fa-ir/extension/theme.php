<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading
$_['heading_title']    = 'قالب ها';

// Text
$_['text_success']     = 'قالب با موفقیت ویرایش شد!';

// Column
$_['column_name']      = 'نام قالب';
$_['column_status']    = 'وضعیت';
$_['column_action']    = 'عملیات';

// Error
$_['error_permission'] = 'هشدار: شما اجازه ویرایش قالب ها را ندارید!';
$_['error_extension']   = 'هشدار: افزونه موجود نیست!';
?>