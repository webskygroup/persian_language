<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading
$_['heading_title']    = 'نرخ های واحد پول';

// Text
$_['text_success']     = 'نرخ واحد پول با موفقیت ویرایش شد!';
$_['text_list']        = 'لیست نرخ های واحد پول';

// Column
$_['column_name']      = 'نام نرخ واحد پول';
$_['column_status']    = 'وضعیت';
$_['column_action']    = 'عملیات';

// Error
$_['error_permission'] = 'هشدار: شما اجازه ویرایش نرخ های واحد پول را ندارید!';
$_['error_extension']  = 'هشدار: افزونه موجود نیست!';
?>