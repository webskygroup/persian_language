<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading 
$_['heading_title']    = 'خوراک (فید) ها';

// Text
$_['text_success']     = 'خوراک (فید) با موفقیت ویرایش شد!';
$_['text_list']        = 'لیست خوراک (فید) ها';

// Column
$_['column_name']      = 'نام خوراک (فید) محصول';
$_['column_status']    = 'وضعیت';
$_['column_action']    = 'عملیات';

// Error
$_['error_permission'] = 'هشدار: شما اجازه ویرایش خوراک (فید) ها را ندارید!';
$_['error_extension']  = 'هشدار: افزونه موجود نیست!';
?>