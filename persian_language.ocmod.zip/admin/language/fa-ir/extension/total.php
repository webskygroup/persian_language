<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading
$_['heading_title']     = 'جمع کل سفارش';

// Text
$_['text_success']      = 'جمع کل سفارش با موفقیت ویرایش شد!';

// Column
$_['column_name']       = 'جمع کل سفارش';
$_['column_status']     = 'وضعيت';
$_['column_sort_order'] = 'ترتیب';
$_['column_action']     = 'عملیات';

// Error
$_['error_permission']  = 'هشدار: شما اجازه ویرایش جمع کل سفارش را ندارید!';
$_['error_extension']   = 'هشدار: افزونه موجود نیست!';
?>