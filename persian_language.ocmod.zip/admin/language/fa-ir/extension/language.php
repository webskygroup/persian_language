<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading
$_['heading_title']    = 'زبان ها';

// Text
$_['text_success']     = 'زبان با موفقیت ویرایش شد!';
$_['text_list']        = 'لیست زبان ها';

// Column
$_['column_name']      = 'نام زبان';
$_['column_status']    = 'وضعیت';
$_['column_action']    = 'عملیات';

// Error
$_['error_permission'] = 'هشدار: شما اجازه ویرایش زبان ها را ندارید!';
$_['error_extension']  = 'هشدار: افزونه موجود نیست!';
?>