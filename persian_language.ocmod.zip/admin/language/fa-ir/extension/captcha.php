<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading
$_['heading_title']    = 'کدهای امنیتی';

// Text
$_['text_success']     = 'کد امنیتی با موفقیت ویرایش شد!';
$_['text_list']        = 'لیست کد امنیتی';

// Column
$_['column_name']      = 'نام کد امنیتی';
$_['column_status']    = 'ضوعیت';
$_['column_action']    = 'عملیات';

// Error
$_['error_permission'] = 'هشدار: شما اجازه ویرایش کد امنیتی را ندارید!';
$_['error_extension']  = 'هشدار: افزونه موجود نیست!';
?>