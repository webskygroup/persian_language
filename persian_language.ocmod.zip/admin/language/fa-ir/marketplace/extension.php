<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading
$_['heading_title'] = 'افزونه ها';

// Text
$_['text_success']  = 'افزونه با موفقیت ویرایش شد!';
$_['text_list']     = 'لیست افزونه ها';
$_['text_type']     = 'نوع افزونه را انتخاب نمایید';
$_['text_filter']   = 'فیلتر';

?>