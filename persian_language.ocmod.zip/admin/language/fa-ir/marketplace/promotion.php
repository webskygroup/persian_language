<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Text
$_['text_recommended'] = 'توصیه شده';
$_['text_install']     = 'نصب';
$_['text_uninstall']   = 'خروج از نصب';
$_['text_delete']      = 'حذف';
?>