<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Text
$_['text_subject']   = '%s - درخواست GDPR پردازش شده است!';
$_['text_request']   = 'درخواست حذف حساب کاربری';
$_['text_hello']     = 'سلام <strong>%s</strong>,';
$_['text_user']      = 'کاربر';
$_['text_delete']    = 'درخواست حذف اطلاعات GDPR شما اکنون تکمیل شده است.';
$_['text_contact']   = 'برای اطلاعات بیشتر شما می توانید با مدیریت فروشگاه تماس بگیرید:';
$_['text_thanks']    = 'متشکریم،';

// Button
$_['button_contact'] = 'تماس با ما';
?>