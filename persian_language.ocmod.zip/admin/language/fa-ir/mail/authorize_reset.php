<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Text
$_['text_subject'] = 'درخواست بازنشانی کد امنیتی';
$_['text_reset']   = 'فردی کد امنیتی را بیشتر از 3 بار اشتباه وارد کرده است.';
$_['text_link']    = 'برای بازنشانی کد امنیتی حساب کاربری روی لینک زیر کلیک کنید:';
$_['text_ip']      = 'آی پی:';
$_['text_regards'] = 'با احترام';
?>