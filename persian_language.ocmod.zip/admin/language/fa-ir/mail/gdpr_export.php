<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Text
$_['text_subject']    = '%s - درخواست خروجی GDPR تکمیل شد!';
$_['text_request']    = 'خروجی اطلاعات شخصی';
$_['text_hello']      = 'سلام <strong>%s</strong>,';
$_['text_user']       = 'کاربر';
$_['text_gdpr']       = 'درخواست GDPR شما هم اکنون تکمیل شده است. در زیر شما می توانید اطلاعات GDPR خود را پیدا کنید.';
$_['text_account']    = 'حساب کاربری';
$_['text_customer']   = 'اطلاعات شخصی';
$_['text_address']    = 'آدرس';
$_['text_addresses']  = 'آدرس ها';
$_['text_name']       = 'نام مشتری';
$_['text_recipient']  = 'دریافت کننده';
$_['text_email']      = 'ایمیل';
$_['text_telephone']  = 'تلفن';
$_['text_company']    = 'شرکت';
$_['text_address_1']  = 'آدرس 1';
$_['text_address_2']  = 'آدرس 2';
$_['text_postcode']   = 'کدپستی';
$_['text_city']       = 'شهر';
$_['text_country']    = 'کشور';
$_['text_zone']       = 'استان';
$_['text_history']    = 'تاریخچه ورود';
$_['text_ip']         = 'آی پی';
$_['text_date_added'] = 'تاریخ افزودن';
$_['text_thanks']     = 'متشکریم،';
?>