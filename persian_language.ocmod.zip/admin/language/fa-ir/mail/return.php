<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Text
$_['text_subject']       = '%s - بروزرسانی برگشت %s';
$_['text_return_id']     = 'شناسه برگشت:';
$_['text_date_added']    = 'تاريخ برگشت:';
$_['text_return_status'] = 'برگشت شما به وضعيت زير بروزرسانی شد:';
$_['text_comment']       = 'توضيحات برگشت:';
$_['text_footer']        = 'لطفا اگر هرگونه سوالی دارید به همین ایمیل ارسال نمایید.';
?>