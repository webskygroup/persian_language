<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Text
$_['text_subject'] = 'امنیت';
$_['text_code']    = 'شما باید کد امنیتی را در بخش کد امنیتی مدیریت وارد نمایید.';
$_['text_ip']      = 'آی پی:';
$_['text_regards'] = 'با احترام';
?>