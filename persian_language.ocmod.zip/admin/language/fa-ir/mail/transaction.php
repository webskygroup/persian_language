<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Text
$_['text_subject']  = '%s - کمیسیون بازاریابی';
$_['text_received'] = 'شما %s کميسيون بازاريابی دريافت کرديد.';
$_['text_total']    = 'کل مبلغ کمیسیون در حال حاضر برابر است با %s.';
$_['text_credit']   = 'اعتبار حساب کاربری شما به صورت خودکار از خرید بعدی شما کسر خواهد شد.';
?>