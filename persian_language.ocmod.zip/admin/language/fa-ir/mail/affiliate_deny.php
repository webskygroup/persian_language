<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Text
$_['text_subject'] = '%s - حساب بازاریابی شما پذیرفته نشد!';
$_['text_welcome'] = 'خوش آمدید و از شما برای ثبت نام در %s متشکریم!';
$_['text_denied']  = 'متاسفانه درخواست شما پذیرفته نشده است. برای اطلاعات بیشتر شما می توانید از اینجا با مدیریت فروشگاه تماس بگیرید:';
$_['text_thanks']  = 'متشکریم،';
?>