<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Text
$_['text_subject']  = '%s - در خواست تغییر رمز عبور';
$_['text_greeting'] = 'درخواست رمز عبور جدید بخش مدیریت %s.';
$_['text_change']   = 'برای تغییر رمز عبور بر روی لینک زیر کلیک نمایید:';
$_['text_ip']       = 'درخواست تغییر رمز عبور از طریق این آی پی آدرس بوده است:';
?>