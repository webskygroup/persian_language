<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Text
$_['text_subject'] = '%s - درخواست GDPR تایید شد!';
$_['text_request'] = 'درخواست حذف حساب کاریری';
$_['text_hello']   = 'سلام <strong>%s</strong>,';
$_['text_user']    = 'کاربر';
$_['text_gdpr']    = 'درخواست حذف اطلاعات GDPR شما تایید شده است و در <strong>%s روز</strong> حذف انجام می شود.';
$_['text_q']       = 'Q. چرا ما اطلاعات شما را فوراً حذف نمی کنیم؟';
$_['text_a']       = 'A. درخواست حذف اطلاعات حساب بعد از <strong>%s روز</strong> پردازش می شود، بنابراین هرگونه بازپرداخت، بازپرداخت یا تشخیص کلاهبرداری قابل پردازش است.';
$_['text_delete']  = 'زمانی که حساب کاربری شما حذف شود از طریق ایمیل به شما اطلاع داده می شود.';
$_['text_thanks']  = 'متشکریم،';
?>