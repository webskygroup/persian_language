<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Text
$_['text_subject']   = '%s - درخواست GDPR رد شد!';
$_['text_export']    = 'درخواست خروجی اطلاعات حساب';
$_['text_remove']    = 'درخواست حذف حساب کاربری';
$_['text_hello']     = 'سلام <strong>%s</strong>,';
$_['text_user']      = 'کاربر';
$_['text_contact']   = 'متاسفانه درخواست شما رد شده است. برای اطلاعات بیشتر با مدیریت فروشگاه تماس بگیرید:';
$_['text_thanks']    = 'متشکریم،';

// Button
$_['button_contact'] = 'تماس با ما';
?>