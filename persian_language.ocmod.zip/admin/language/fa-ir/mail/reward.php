<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Text
$_['text_subject']  = '%s - امتیاز جایزه';
$_['text_received'] = 'شما %s اعتبار جایزه دریافت کردید.';
$_['text_total']    = 'کل اعتبار جایزه شما برابر است با %s.';
?>