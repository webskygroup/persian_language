<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Text
$_['text_subject'] 	 = '%s - حساب کاربری شما پذیرفته نشد!';
$_['text_welcome'] 	 = 'خوش آمدید و از عضویت شما در %s متشکریم!';
$_['text_denied']	 = 'متاسفانه درخواست شما پذیرفته نشده است. برای اطلاعات بیشتر شما می توانید از اینجا با مدیریت فروشگاه تماس بگیرید:';
$_['text_thanks']  	 = 'متشکریم،';

// Button
$_['button_contact'] = 'تماس با ما';
?>