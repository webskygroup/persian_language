<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading
$_['heading_title'] = 'گزارش ها';

// Text
$_['text_success']  = 'گزارش با موفقیت ویرایش شد!';
$_['text_type']     = 'نوع گزارش را انتخاب نمایید';
$_['text_filter']   = 'فیلتر';
?>