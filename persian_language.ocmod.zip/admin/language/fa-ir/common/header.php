<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading
$_['heading_title']      = 'اپن کارت فارسی';

// Text
$_['text_notification']      = 'اطلاعیه ها';
$_['text_notification_all']  = 'مشاهده همه';
$_['text_notification_none'] = 'هیچ اطلاعیه ای موجود نیست';
$_['text_profile']           = 'پروفایل شما';
$_['text_store']         	 = 'فروشگاه ها';
$_['text_help']          	 = 'راهنمایی و پشتیبانی';
$_['text_homepage']      	 = 'وب سایت اصلی اپن کارت';
$_['text_support']       	 = 'انجمن پشتیبانی';
$_['text_website']   	 	 = 'وب سایت اپن کارت فارسی';
$_['text_shop']      	 	 = 'فروشگاه اپن کارت فارسی';
$_['text_documentation'] 	 = 'مستندات';
$_['text_logout']        	 = 'خروج';     
?>