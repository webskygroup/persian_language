<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

$_['error_language'] = 'هشدار: زبان پیدا نشد!';
?>