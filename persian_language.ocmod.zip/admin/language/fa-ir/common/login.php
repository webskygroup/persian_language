<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Heading
$_['heading_title']  = 'مديريت';

// Text
$_['text_heading']   = 'مديريت';
$_['text_login']     = 'لطفا اطلاعات خود را وارد نمایید.';
$_['text_forgotten'] = 'فراموشی رمز عبور';

// Entry
$_['entry_username'] = 'نام کاربری';
$_['entry_password'] = 'رمز عبور';

// Button
$_['button_login']   = 'ورود';

// Error
$_['error_login']    = 'نام کاربری و یا رمز عبور وارد شده صحیح نمی‌باشد.';
$_['error_token']    = 'اطلاعات نشست موجود نیست. لطفا دوباره وارد شويد.';
?>