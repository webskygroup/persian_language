<?php
// Forum  : WwW.OpenCartFarsi.com
// Website: WwW.OpenCartFarsi.ir
// E-Mail : info@OpenCartFarsi.ir

// Text
$_['text_footer']  = 'تمامی حقوق برای <a target="_blank" href="https://www.opencartfarsi.com" title="OpenCart-ir.Com">اپن کارت فارسی دات کام</a>|<a target="_blank" href="https://www.opencart-ir.com" title="OpenCart-ir.Com">اپن کارت پارسی</a> محفوظ است. &copy; 2009-' . date('Y') . ' ';
$_['text_version'] = 'نسخه %s';

?>